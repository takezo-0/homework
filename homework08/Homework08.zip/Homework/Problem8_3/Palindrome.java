package Problem8_3;

// Delta College - CST 283 - Klingler
// This program reads a string object from the user and determines
// if the word stored within is a palindrome or not

import javax.swing.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Palindrome
{
    private static String rawData = "";
    public static void main(String[] args)
    {
        String readString = "";
        try{
            BufferedReader br = new BufferedReader(new FileReader("palindromes.txt"));
            while (br.ready()) {
                readString += br.readLine() + "\n";
            }

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
//        String theWord = JOptionPane.showInputDialog(null, "Enter a string: ");

        for (String theWord : readString.split("\n")) {
            if (isPalindrome(theWord)) {
                JOptionPane.showMessageDialog(null, theWord + " is a palindrome");
            } else {
                JOptionPane.showMessageDialog(null, theWord + " is not a palindrome");
            }
        }
        System.exit(0);
    }

    // This method receives a string object and returns TRUE
    // if the object represents a palindrom and FALSE otherwise
    public static boolean isPalindrome(String word)
    {
        LinkedQueue<String> charQueue = new LinkedQueue<String>();
        LinkedStack<String> charStack = new LinkedStack<String>();

        boolean palindromeOK = true;       // Assume a palindrom until detecting otherwise

        // Traverse characters of word, In sequence, push into a stack
        // and enqueue into a queue.
        int len = word.length();
        for (int i = 0; i < len; i++)
        {
            charStack.push(word.substring(i,i+1));
            charQueue.enqueue(word.substring(i,i+1));
        }
        // Pop and access characters in reverse order.  Match with
        // corresponding character in queue.  Any mismatch would
        // disqualify string as a palindrome
        String fromQueue, fromStack;
        while (!charStack.isEmpty()) {
            // Get next characters from queue and stack
            fromStack = charStack.pop();
            fromQueue = charQueue.dequeue();

            // Test for mismatch
            if (! fromStack.equalsIgnoreCase(fromQueue))
                palindromeOK = false;
        }

        return palindromeOK;
    }
}

/*
Since you're compiling Java files that are in distinct packages, you'll have to ensure that they compile to the
appropriate directories.

You can use this invocation to do just that. Substitute $SRC with the location of your source files, and you can
let $BIN be the current directory, or some other location on your machine.

javac -sourcepath $SRC -d $BIN A.java B.java
When you want to run them, you have to add them manually to the classpath again (but that's not such a bad
thing).

java -cp $BIN com.mypackage.B
This invocation should work; just made sure of it with A.java and B.java residing on my desktop. With the -d flag,
that ensured that when they compiled, they went to the appropriate package folder scheme.
*/
